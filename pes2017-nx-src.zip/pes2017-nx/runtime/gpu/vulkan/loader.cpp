// Filling in the pointers loader.h declares.
#include "loader.h"

#if defined(PES17_VULKAN_DYNAMIC) && defined(PES17_HAVE_VULKAN)

#include "../../log.h"

#if defined(__SWITCH__)
#include "switch_driver.h"
#else
#include <dlfcn.h>
#endif

#include <atomic>
#include <cstring>
#include <mutex>

extern "C"
{
    PFN_vkGetInstanceProcAddr vkGetInstanceProcAddrFn = nullptr;

#define PES17_VK_GLOBAL(name)   PFN_##name name = nullptr;
#define PES17_VK_INSTANCE(name) PFN_##name name = nullptr;
#define PES17_VK_DEVICE(name)   PFN_##name name = nullptr;
#include "vulkan_functions.inc"
#undef PES17_VK_GLOBAL
#undef PES17_VK_INSTANCE
#undef PES17_VK_DEVICE
}

namespace
{
    std::mutex g_lock;
    bool g_opened = false;
    std::string g_description = "not opened";
    uint32_t g_missing = 0;
    VkInstance g_instance = VK_NULL_HANDLE;

    // A name that came back null is counted and named once: a driver without
    // vkCmdBeginRenderingKHR is a driver this renderer cannot use, and
    // "crashed in renderer_draw.cpp" is not the way to find that out.
    template <typename Pointer>
    void Take(Pointer& slot, PFN_vkVoidFunction address, const char* name, bool required)
    {
        slot = reinterpret_cast<Pointer>(address);
        if (slot || !required) return;
        if (g_missing < 12) LOGW("vulkan: this driver has no %s", name);
        g_missing++;
    }
}

bool vk::loader::Opened() { return g_opened; }
const char* vk::loader::Description() { return g_description.c_str(); }
uint32_t vk::loader::Missing() { return g_missing; }

bool vk::loader::Open(std::string& error)
{
    std::lock_guard lock(g_lock);
    if (g_opened) return true;

    void* entry = nullptr;
#if defined(__SWITCH__)
    // Horizon has no system Vulkan loader. Keep the statically linked driver
    // behind its own adapter; the Vulkan loader/provider code stays driver-agnostic.
    entry = reinterpret_cast<void*>(vk::switch_driver::GetInstanceProcAddr());
    g_description = vk::switch_driver::Description();
#else
    // A desktop build with dynamic loading asked for: the system's loader.
    for (const char* name : { "libvulkan.so.1", "libvulkan.so" })
    {
        void* library = dlopen(name, RTLD_NOW | RTLD_LOCAL);
        if (!library) continue;
        entry = dlsym(library, "vkGetInstanceProcAddr");
        if (entry) { g_description = name; break; }
        dlclose(library);
    }
    if (!entry) error = "libvulkan could not be loaded";
#endif
    if (!entry)
    {
        if (error.empty()) error = "Vulkan implementation entry point is unavailable";
        LOGE("vulkan: %s", error.c_str());
        return false;
    }

    // A failed first attempt may be retried after the platform has made the
    // driver available. Do not carry missing-symbol counts from that attempt.
    g_missing = 0;
    vkGetInstanceProcAddrFn = reinterpret_cast<PFN_vkGetInstanceProcAddr>(entry);

    // What can be had without an instance. vkEnumerateInstanceVersion is
    // Vulkan 1.1 and may be absent on a 1.0 implementation, which is not an
    // error -- the caller treats null as "1.0".
#define PES17_VK_GLOBAL(name) \
    Take(name, vkGetInstanceProcAddrFn(nullptr, #name), #name, \
         std::strcmp(#name, "vkEnumerateInstanceVersion") != 0);
#define PES17_VK_INSTANCE(name)
#define PES17_VK_DEVICE(name)
#include "vulkan_functions.inc"
#undef PES17_VK_GLOBAL
#undef PES17_VK_INSTANCE
#undef PES17_VK_DEVICE

    if (g_missing)
    {
        error = "the Vulkan implementation is missing " + std::to_string(g_missing) +
                " required global entry point(s)";
        LOGE("vulkan: %s (%s)", error.c_str(), g_description.c_str());
        return false;
    }
    if (!vkCreateInstance)
    {
        error = "the Vulkan library has no vkCreateInstance";
        LOGE("vulkan: %s (%s)", error.c_str(), g_description.c_str());
        return false;
    }
    g_opened = true;
    LOGI("vulkan: %s", g_description.c_str());
    return true;
}

void vk::loader::LoadInstance(VkInstance instance)
{
    std::lock_guard lock(g_lock);
    g_instance = instance;
    // Surface and debug entry points belong to extensions that may not be
    // enabled; the renderer checks for them itself.
#define PES17_VK_GLOBAL(name)
#define PES17_VK_INSTANCE(name) \
    Take(name, vkGetInstanceProcAddrFn(instance, #name), #name, \
         std::strstr(#name, "Surface") == nullptr && std::strstr(#name, "Debug") == nullptr && \
         std::strstr(#name, "Android") == nullptr);
#define PES17_VK_DEVICE(name) \
    Take(name, vkGetInstanceProcAddrFn(instance, #name), #name, \
         std::strstr(#name, "KHR") == nullptr && std::strstr(#name, "EXT") == nullptr);
#include "vulkan_functions.inc"
#undef PES17_VK_GLOBAL
#undef PES17_VK_INSTANCE
#undef PES17_VK_DEVICE
    LOGI("vulkan: instance entry points loaded%s",
         g_missing ? " (some are missing, see above)" : "");
}

bool vk::loader::LoadDevice(VkDevice device)
{
    std::lock_guard lock(g_lock);
    if (!vkGetDeviceProcAddr || !device)
    {
        LOGW("vulkan: cannot load device dispatch without vkGetDeviceProcAddr and a device");
        return false;
    }
    uint32_t taken = 0;
    uint32_t missing = 0;
#define PES17_VK_GLOBAL(name)
#define PES17_VK_INSTANCE(name)
#define PES17_VK_DEVICE(name) \
    name = reinterpret_cast<PFN_##name>(vkGetDeviceProcAddr(device, #name)); \
    if (name) taken++; \
    else if (std::strstr(#name, "KHR") == nullptr && std::strstr(#name, "EXT") == nullptr) \
    { \
        if (missing < 12) LOGW("vulkan: this device has no required core entry point %s", #name); \
        missing++; \
    }
#include "vulkan_functions.inc"
#undef PES17_VK_GLOBAL
#undef PES17_VK_INSTANCE
#undef PES17_VK_DEVICE
    LOGI("vulkan: %u device entry points taken straight from the driver", taken);
    if (missing)
        LOGW("vulkan: device dispatch is incomplete (%u required core entry point(s) missing)", missing);
    return missing == 0;
}

// The device is going: its entry points must not be called again, so they go
// back to the instance's, which dispatch on whatever they are handed.
void vk::loader::ForgetDevice()
{
    std::lock_guard lock(g_lock);
    if (!g_instance) return;
#define PES17_VK_GLOBAL(name)
#define PES17_VK_INSTANCE(name)
#define PES17_VK_DEVICE(name) name = reinterpret_cast<PFN_##name>(vkGetInstanceProcAddrFn(g_instance, #name));
#include "vulkan_functions.inc"
#undef PES17_VK_GLOBAL
#undef PES17_VK_INSTANCE
#undef PES17_VK_DEVICE
}

void vk::loader::ForgetInstance()
{
    std::lock_guard lock(g_lock);
    if (!g_instance) return;
#define PES17_VK_GLOBAL(name)
#define PES17_VK_INSTANCE(name) name = reinterpret_cast<PFN_##name>(vkGetInstanceProcAddrFn(VK_NULL_HANDLE, #name));
#define PES17_VK_DEVICE(name) name = reinterpret_cast<PFN_##name>(vkGetInstanceProcAddrFn(VK_NULL_HANDLE, #name));
#include "vulkan_functions.inc"
#undef PES17_VK_GLOBAL
#undef PES17_VK_INSTANCE
#undef PES17_VK_DEVICE
    g_instance = VK_NULL_HANDLE;
}

#endif  // PES17_VULKAN_DYNAMIC && PES17_HAVE_VULKAN
