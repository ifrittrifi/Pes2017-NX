#include "../platform.h"

#include "../../switch/source/input.h"

#include <switch.h>

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "profiler_nx.h"
#include <cstring>
#include <new>

#include <sys/stat.h>
#include <unistd.h>

// Everything comes out of the libnx heap: the guest memory (memalign,
// runtime/switch/guest_memory_nx.cpp), the host thread stacks and Mesa's GPU
// memory. Started by hbloader the heap is handed over already sized (all of
// the process's memory but ~2 MB) and this value is ignored; started any other
// way, 0 asks libnx for the same.
extern "C"
{
    u32 __nx_applet_type = AppletType_Application;
    size_t __nx_heap_size = 0;
}

// libnx does not expose POSIX thread names, backtraces, or dlopen-compatible
// process services. Keep those operations explicit rather than importing the
// desktop implementation's Linux headers into the Switch target.

namespace
{
    // Cores the title may run on: the process mask without core 3 (the
    // system's). A thread created with core -2 is pinned to the process's
    // default core alone, so every thread used to share core 0.
    u32 AllowedCores()
    {
        static const u32 mask = []
        {
            u64 process = 0;
            if (R_FAILED(svcGetInfo(&process, InfoType_CoreMask, CUR_PROCESS_HANDLE, 0)) || !process)
                process = 1;
            const u32 title = u32(process) & 0x7u;
            return title ? title : u32(process) & 0xFu;
        }();
        return mask;
    }

    int NthCore(unsigned n)
    {
        int cores[4];
        int count = 0;
        const u32 mask = AllowedCores();
        for (int i = 0; i < 4; ++i)
            if (mask & (1u << i)) cores[count++] = i;
        return count ? cores[n % unsigned(count)] : 0;
    }

    // Preferred core only; the mask stays all title cores so the kernel can
    // still move a thread off a busy core.
    void PlaceThread(Handle thread, int preferred)
    {
        const u32 mask = AllowedCores();
        if (!(mask & (1u << preferred))) preferred = NthCore(0);
        svcSetThreadCoreMask(thread, preferred, mask);
    }

    // Core 3 when the process was granted it (a forwarder with a 4-core NPDM);
    // -1 otherwise. Only threads pinned there alone run on it.
    int SystemCore()
    {
        static const int core = []
        {
            u64 process = 0;
            if (R_FAILED(svcGetInfo(&process, InfoType_CoreMask, CUR_PROCESS_HANDLE, 0))) return -1;
            return (process & 0x8u) && (process & 0x7u) ? 3 : -1;
        }();
        return core;
    }

    // Horizon: lower is more urgent. Guest threads run at 0x3B.
    constexpr s32 kRenderPriority = 0x2D;   // GPU ring consumer, presenter, recorder
    constexpr s32 kAudioPriority = 0x2C;    // the mixer: a late frame is an audible gap

    // Core 0 is the main thread's: new threads start on 1, 2, 0, 1, ...
    std::atomic<unsigned> g_nextCore{ 1 };
    std::atomic<unsigned> g_renderThreads{ 0 };

    u64 g_mainThreadId = 0;

    struct ThreadControl
    {
        Thread thread{};
        void (*body)(void*) = nullptr;
        void* argument = nullptr;
        char name[16]{};
    };

    // libnx requires the Thread object and its backing stack/TLS to remain
    // alive until the kernel thread has exited and threadClose has run.
    // The current runtime API is detached and has no join/reap operation, so
    // controls are retained for the process lifetime. This is bounded by the
    // number of runtime worker threads and avoids use-after-free on exit.

    void ThreadEntry(void* raw)
    {
        auto* control = static_cast<ThreadControl*>(raw);
        control->body(control->argument);
    }

    u32 CurrentThreadId()
    {
        u64 id = 0;
        if (R_FAILED(svcGetThreadId(&id, CUR_THREAD_HANDLE))) return 0;
        return static_cast<u32>(id);
    }
}

void platform::Initialise()
{
    g_mainThreadId = CurrentThreadId();


    // The runtime keeps its own VkPipelineCache on SD (vulkan/pipeline.cpp);
    // Mesa's disk cache beside it would only add SD writes during play.
    setenv("MESA_SHADER_CACHE_DISABLE", "true", 0);

    // The runtime's player install layout lives on SD. Mount it before
    // settings, install discovery, or any game files are opened.
    const Result mounted = fsdevMountSdmc();
    if (R_FAILED(mounted))
    {
        constexpr char message[] = "[PES17] failed to mount SD card filesystem\n";
        svcOutputDebugString(message, sizeof(message) - 1);
    }
    else
    {
        mkdir("sdmc:/switch", 0777);
        mkdir("sdmc:/switch/PES2017", 0777);
        if (chdir("sdmc:/switch/PES2017") != 0)
        {
            constexpr char message[] = "[PES17] failed to enter sdmc:/switch/PES2017\n";
            svcOutputDebugString(message, sizeof(message) - 1);
        }
    }

    // Settings without a rebuild: sdmc:/switch/PES2017/env.txt, KEY=VALUE a
    // line (# starts a comment), read before anything looks at its variables.
    if (FILE* env = std::fopen("sdmc:/switch/PES2017/env.txt", "r"))
    {
        char line[256];
        while (std::fgets(line, sizeof line, env))
        {
            char* text = line;
            while (*text == ' ' || *text == '\t') ++text;
            if (*text == '#' || *text == '\0' || *text == '\n' || *text == '\r') continue;
            char* equals = std::strchr(text, '=');
            if (!equals) continue;
            *equals = '\0';
            char* value = equals + 1;
            value[std::strcspn(value, "\r\n")] = '\0';
            for (char* end = equals; end > text && (end[-1] == ' ' || end[-1] == '\t'); --end) end[-1] = '\0';
            while (*value == ' ' || *value == '\t') ++value;
            if (*text) setenv(text, value, 1);
        }
        std::fclose(env);
    }
    profiler_nx::Start();

    // Input remains usable even when the SD card is absent or cannot mount.
    switch_input::Initialize();
}

uint32_t platform::ThreadId()
{
    return CurrentThreadId();
}

bool platform::IsMainThread()
{
    return g_mainThreadId != 0 && CurrentThreadId() == g_mainThreadId;
}

void platform::SetThreadName(const char* name)
{
    // Horizon does not provide a public thread-name service through libnx.
    (void)name;
}

void platform::LowerThreadPriority()
{
    // 0x3B is libnx's documented preemptive-multithreading priority.
    svcSetThreadPriority(threadGetCurHandle(), 0x3B);
}

void platform::IdleThreadPriority()
{
    // 0x3F is the lowest priority in the libnx thread priority range.
    svcSetThreadPriority(threadGetCurHandle(), 0x3F);
}

void platform::SetThreadAffinity(ThreadAffinityRole role)
{
    const Handle self = threadGetCurHandle();
    switch (role)
    {
    case ThreadAffinityRole::PrimeCore:
        PlaceThread(self, NthCore(0));
        break;
    case ThreadAffinityRole::RenderCore:
        // The GPU ring consumer first (heavy), then the presenter.
        PlaceThread(self, NthCore(1 + g_renderThreads.fetch_add(1, std::memory_order_relaxed)));
        svcSetThreadPriority(self, kRenderPriority);
        break;
    case ThreadAffinityRole::AudioCore:
        if (SystemCore() >= 0) svcSetThreadCoreMask(self, SystemCore(), 1u << SystemCore());
        else PlaceThread(self, NthCore(2));
        svcSetThreadPriority(self, kAudioPriority);
        break;
    case ThreadAffinityRole::PerformanceCore:
        PlaceThread(self, NthCore(g_nextCore.fetch_add(1, std::memory_order_relaxed)));
        break;
    case ThreadAffinityRole::WorkerCore:
        PlaceThread(self, NthCore(2));
        break;
    case ThreadAffinityRole::Default:
        break;
    }
}

void platform::PrintBacktrace(const char* why)
{
    const char* message = why ? why : "unspecified";
    constexpr char prefix[] = "[PES17] backtrace unavailable on Switch: ";
    svcOutputDebugString(prefix, sizeof(prefix) - 1);
    svcOutputDebugString(message, std::strlen(message));
    svcOutputDebugString("\n", 1);
}

bool platform::StartThread(void (*body)(void*), void* argument, size_t stackBytes,
                           const char* name)
{
    if (!body) return false;

    auto* control = new (std::nothrow) ThreadControl{};
    if (!control) return false;

    control->body = body;
    control->argument = argument;
    if (name) std::snprintf(control->name, sizeof(control->name), "%s", name);

    // libnx allocates stack/TLS storage when stack_mem is NULL. Round the
    // requested guest-worker stack up to a page boundary.
    constexpr size_t kPageSize = 0x1000;
    stackBytes = std::max(stackBytes, size_t(0x4000));
    stackBytes = (stackBytes + kPageSize - 1) & ~(kPageSize - 1);

    Result rc = threadCreate(&control->thread, ThreadEntry, control, nullptr,
                             stackBytes, 0x3B, -2);
    if (R_FAILED(rc))
    {
        delete control;
        return false;
    }
    PlaceThread(control->thread.handle, NthCore(g_nextCore.fetch_add(1, std::memory_order_relaxed)));

    rc = threadStart(&control->thread);
    if (R_FAILED(rc))
    {
        threadClose(&control->thread);
        delete control;
        return false;
    }

    // The control remains allocated because the runtime's detached-thread API
    // has no join/reap callback with which to safely release libnx resources.
    return true;
}

platform::ThreadHandle platform::StartJoinableThread(void (*body)(void*), void* argument,
                                                      size_t stackBytes, const char* name)
{
    if (!body) return nullptr;
    auto* control = new (std::nothrow) ThreadControl{};
    if (!control) return nullptr;
    control->body = body;
    control->argument = argument;
    if (name) std::snprintf(control->name, sizeof(control->name), "%s", name);

    constexpr size_t kPageSize = 0x1000;
    stackBytes = std::max(stackBytes, size_t(0x4000));
    stackBytes = (stackBytes + kPageSize - 1) & ~(kPageSize - 1);
    Result rc = threadCreate(&control->thread, ThreadEntry, control, nullptr,
                             stackBytes, 0x3B, -2);
    if (R_FAILED(rc)) { delete control; return nullptr; }
    PlaceThread(control->thread.handle, NthCore(g_nextCore.fetch_add(1, std::memory_order_relaxed)));
    rc = threadStart(&control->thread);
    if (R_FAILED(rc))
    {
        threadClose(&control->thread);
        delete control;
        return nullptr;
    }
    return control;
}

void platform::JoinThread(ThreadHandle handle)
{
    auto* control = static_cast<ThreadControl*>(handle);
    if (!control) return;
    threadWaitForExit(&control->thread);
    threadClose(&control->thread);
    delete control;
}

void* platform::OpenLibrary(const char* path)
{
    (void)path;
    return nullptr;
}

void* platform::LoadedLibrary(const char* name)
{
    (void)name;
    return nullptr;
}

void* platform::Symbol(void* library, const char* name)
{
    (void)library;
    (void)name;
    return nullptr;
}
